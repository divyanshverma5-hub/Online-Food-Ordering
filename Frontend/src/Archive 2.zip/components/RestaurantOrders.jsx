import React, { useEffect, useState } from "react";
import ViewItems from "./ViewItems";
import RestaurantNavbar from "./RestaurantNavbar";
import "../style/restarauntorders.css";

function RestaurantOrders(){
    let restaurant_id = localStorage.getItem("id");
    const [detail, setDetail] = useState([]);
    const [dishes, setDishes] = useState([]);
    const [show, setShow] = useState("");
    let pending = detail.filter((i) => i.status == "Pending");
    let active = detail.filter((i) => (
        i.status != "Delivered" &&
        i.status != "Pending" &&
        i.status != "Rejected"
    ));
    let history = detail.filter((i) => (
        i.status == "Delivered" ||
        i.status == "Rejected"
    ));
    let getData = async () => {

        let result = await fetch(`http://localhost:3000/order/restaurant/details?id=${restaurant_id}`);

        result = await result.json();

        setDetail(result.detail);
    }
    useEffect(() => {
        getData();
    }, []);
    async function seeDishes(order_id){
        let result = await fetch(`http://localhost:3000/order/seeDishes?id=${order_id}`);
        result = await result.json();
        setDishes(result.dishes);
        if(show === order_id){
            setShow(null);
        }
        else{
            setShow(order_id);
        }
    }
    async function handleChoice(choice, order_id){
        await fetch("http://localhost:3000/order/changeStatus", {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                choice,
                order_id
            })
        });
        getData();
    }
    function statusClass(status){
        if(status === "Delivered"){
            return "r-badge r-badge-delivered";
        }
        if(status === "Rejected"){
            return "r-badge r-badge-rejected";
        }
        if(status === "Pending"){
            return "r-badge r-badge-pending";
        }
        return "r-badge r-badge-active";
    }
    return(
        <>
            <RestaurantNavbar />
            <div className="rorders-page">
                <div className="rorders-header">
                    <h1>Orders</h1>
                    <p className="rorders-subtitle">
                        Manage incoming and ongoing orders for your restaurant.
                    </p>
                </div>
                <section className="rorders-section">
                    <div className="rorders-section-title">
                        <span>
                            🟢 New Orders
                        </span>
                        <span className="count-badge">
                            {pending.length}
                        </span>
                    </div>
                    <div className="rorders-grid">
                        {
                            pending.length === 0 &&
                            <p className="empty-orders">
                                No new orders.
                            </p>
                        }
                        {
                            pending.map((i) => {
                                return(
                                    <div
                                        className="rorder-card"
                                        key={i.id}
                                    >
                                        <div className="rorder-card-top">
                                            <div>
                                                <h2>
                                                    Order #{i.id}
                                                </h2>
                                                <p className="rorder-meta">
                                                    {i.name} • {new Date(i.order_at).toLocaleString()}
                                                </p>
                                            </div>
                                            <span className={statusClass(i.status)}>
                                                {i.status}
                                            </span>
                                        </div>
                                        <p className="rorder-total">
                                            ₹{i.total_price}
                                        </p>
                                        <div className="rorder-actions">
                                        <button
                                                className="btn-outline"
                                                onClick={() => seeDishes(i.id)}
                                            >
                                                View Details
                                            </button>
                                            <button
                                                className="btn-accept"
                                                onClick={() => handleChoice("Preparing", i.id)}
                                            >
                                                Accept
                                            </button>
                                            <button
                                                className="btn-reject"
                                                onClick={() => handleChoice("Rejected", i.id)}
                                            >
                                                Reject
                                            </button>
                                        </div>
                                        {
                                            show == i.id &&
                                            <ViewItems
                                                order={i}
                                                dishes={dishes}
                                            />
                                        }
                                    </div>
                                );
                            })
                        }
                    </div>
                </section>
                <section className="rorders-section">
                    <div className="rorders-section-title">
                        <span>
                            🟡 Active Orders
                        </span>
                        <span className="count-badge">
                            {active.length}
                        </span>
                    </div>
                    <div className="rorders-grid">
                        {
                            active.length === 0 &&
                            <p className="empty-orders">
                                No active orders.
                            </p>
                        }
                        {
                            active.map((i) => {
                                return(
                                    <div
                                        className="rorder-card"
                                        key={i.id}
                                    >
                                        <div className="rorder-card-top">
                                            <div>
                                                <h2>
                                                    Order #{i.id}
                                                </h2>
                                                <p className="rorder-meta">
                                                    {i.name} • {new Date(i.order_at).toLocaleString()}
                                                </p>
                                            </div>
                                            <span className={statusClass(i.status)}>
                                                {i.status}
                                            </span>
                                        </div>
                                        <p className="rorder-total">
                                            ₹{i.total_price}
                                        </p>
                                        <div className="rorder-actions">
                                            <select
                                                className="status-select"
                                                onChange={(e) => handleChoice(e.target.value, i.id)}
                                            >
                                                <option value="Preparing">
                                                    Preparing
                                                </option>
                                                <option value="Ready">
                                                    Ready
                                                </option>
                                                <option value="Out for Delivery">
                                                    Out for Delivery
                                                </option>
                                                <option value="Delivered">
                                                    Delivered
                                                </option>
                                            </select>
                                            <button
                                                className="btn-outline"
                                                onClick={() => seeDishes(i.id)}
                                            >
                                                View Details
                                            </button>
                                        </div>
                                        {
                                            show == i.id &&
                                            <ViewItems
                                                order={i}
                                                dishes={dishes}
                                            />
                                        }
                                    </div>
                                );
                            })
                        }
                    </div>
                </section>
                <section className="rorders-section">
                    <div className="rorders-section-title">
                        <span>
                            Past Orders
                        </span>
                        <span className="count-badge">
                            {history.length}
                        </span>
                    </div>
                    <div className="rorders-grid">
                        {
                            history.length === 0 &&
                            <p className="empty-orders">
                                No past orders yet.
                            </p>
                        }
                        {
                            history.map((i) => {
                                return(
                                    <div
                                        className="rorder-card"
                                        key={i.id}
                                    >
                                       <div className="rorder-card-top">
                                            <div>
                                                <h2>
                                                    Order #{i.id}
                                                </h2>
                                                <p className="rorder-meta">
                                                    {i.name} • {new Date(i.order_at).toLocaleString()}
                                                </p>
                                            </div>
                                            <span className={statusClass(i.status)}>
                                                {i.status}
                                            </span>
                                        </div>
                                        <p className="rorder-total">
                                            ₹{i.total_price}
                                        </p>
                                        <div className="rorder-actions">
                                            <button
                                                className="btn-outline"
                                                onClick={() => seeDishes(i.id)}
                                            >
                                                View Details
                                            </button>
                                        </div>
                                        {
                                            show == i.id &&
                                            <ViewItems
                                                order={i}
                                                dishes={dishes}
                                            />
                                        }
                                    </div>
                                );
                            })
                        }
                    </div>
                </section>
            </div>
        </>
    );
}
export default RestaurantOrders;